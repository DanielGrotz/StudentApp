package com.example.studentapp;

import java.io.IOException;
import java.io.InputStream;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.studentapp.SelectActivity.AsyncConnectSelect;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Spinner;

public class CheckinStudents extends Activity{
	
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.students_checkin);
        
        Intent stuInt = getIntent();// get the incoming intent
    	
    	
    	String result = stuInt.getStringExtra("STU_MESSAGE_RES");
    	
    	String[] StudentArray = ArrayConvert(result);// convert to normal array
        
        
        LinearLayout LL = (LinearLayout)findViewById(R.id.checkLayout);
        for(int i = 0; i < StudentArray.length - 1; i++){// for loop to create each checkbox
        	// get the intent data
        	CheckBox cb = new CheckBox(this);
        	cb.setText(StudentArray[i]);// change to the kids name
        	cb.setId(i);
        	LL.addView(cb);
        	
        }
	}
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
	
	public void Home(View view){
		
		Intent actIntent = new Intent(this,MainActivity.class);
		
		startActivity(actIntent);
		
	}
	private String[] ArrayConvert(String result) {// MOVE TO CheckinStudnets
		
		JSONObject stuObj = null;
		JSONArray stuArr = null;
		String stuStringJ = "X";// DEBUG
		try {
			stuObj = new JSONObject(result);
			stuArr = stuObj.getJSONArray("Campers");// get the correct array
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			Log.e("JsonError", e1.toString());
		}
		String[] stringArray = new String[stuArr.length()];
		
		for(int i = 0; i < stuArr.length() - 1; i++){// loop through json array
			try {
				stuStringJ = stuArr.getJSONObject(i).getString("CamperID");// gets the camper id, first name and last name
				stuStringJ += " " + stuArr.getJSONObject(i).getString("CampFName");// seperated by spaces
				stuStringJ += " " + stuArr.getJSONObject(i).getString("CampLName");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				Log.e("ForLoopError", e.toString());
			}
			
			stringArray[i] = stuStringJ;// adds the string to a regular string array to be used with spinner/checkbox
			//Log.e("Is It Null?", stuStringJ);//DEBUG
		}
		
		
		
		return stringArray;
	}
	
	public void SendData(View view) throws ClientProtocolException, IOException{
		
		String Sndresult = new CheckinData().execute().toString();

		Spinner actSpinner = (Spinner) findViewById(R.id.actSpinner);
		
		//String chosenAct = actSpinner.getSelectedItem().toString();
		
		Intent stuIntent = new Intent(this,SelectActivity.class);
		
		//stuIntent.putExtra("STU_MESSAGE_ACT", chosenAct);// the value C will be replaced with
		// unnecessary to pass on activity data
		stuIntent.putExtra("STU_MESSAGE_RES2", Sndresult);
		
		startActivity(stuIntent);



	}
	
	class CheckinData extends AsyncTask<String, String, String>{// class to send the final student check-in data
																// this class currently returns null

		Spinner actSpinner = (Spinner) findViewById(R.id.actSpinner);// get the spinner
		String stuAct = actSpinner.getSelectedItem().toString();// get the selected item
		
		Intent stuInt = getIntent();
		String block = stuInt.getStringExtra("STU_MESSAGE_BLOCK");
		
		@Override
		// start of Android setup variables
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			//Connection Variables
					String stuUri = "?id=2&block="; //add the correct variable to stuUri for result
													// Separate by & sign
													// id should be 2
													// set the id to the right phase and set variable i to the id in php
					String URL = "http://10.0.2.2:81/phpSwitch.php";
					stuUri += block + "&act=" + stuAct;// adding the block to the uri// also add the act to the uri
											  // get the act from the spinner
					URL += stuUri;// add the query to the url
					
					HttpClient stuClient = new DefaultHttpClient();
					HttpGet stuDataGet = new HttpGet("http://10.9.2.62/httpTest.php");
					InputStream stuin = null;//10.9.2.62 ip address for dunwoody laptop
					HttpResponse stuRes = null;
					String result = null;
					String paramAppend = ""; // used to append the parameters for the get method
					
					
						//try catch section
					
					//if(testConnectivity()){

							try{
							stuRes = stuClient.execute(stuDataGet);// execute the get request
							}catch(Exception e){
								
								Log.e("Client", e.toString());
								e.printStackTrace();
							}

							try{
							stuin = stuRes.getEntity().getContent();// get the content of the response
							
							}catch(Exception e){
								
								Log.e("ENT", e.toString());
								e.printStackTrace();
							}

							
							//result = InStreamReader(stuin);// parse the string

				
							
							
			return result;// change to returning a string
						  // Supposed to be null?
		}
	}
}
