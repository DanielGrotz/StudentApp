package com.example.studentapp;
// imports
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.*;

import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.util.HttpURLConnection;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import android.net.*;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.app.*;
import android.content.Intent;
// main class
public class MainActivity extends Activity implements OnItemSelectedListener{// surrounds async connect
	
	// start of Android setup variables
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);// setting the view
        
        Spinner stuSpinner = (Spinner) findViewById(R.id.blockSpinner);// create spinner
        
        ArrayAdapter<CharSequence> stuAdapter = ArrayAdapter.createFromResource(
        		this, R.array.blockArray, android.R.layout.simple_spinner_dropdown_item);
        		// create array adapter
        		// the data for adapter is in strings.xml in folder values
        stuAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Set the layout
        
        stuSpinner.setAdapter(stuAdapter);
        //Apply the spinner
        
        stuSpinner.setOnItemSelectedListener(this);
        //Apply ItemSelected
        
       // String chosenBlock = stuSpinner.getSelectedItem().toString();// not needed here
        
    }
	
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    //end Android setup variables
    
	public void SendData(View view) throws ClientProtocolException, IOException, InterruptedException, ExecutionException{


		
		String result = new AsyncConnect().execute().get();
		
			// keep the intent variables have the asynctask return the result
		
				Spinner stuSpinner = (Spinner)findViewById(R.id.blockSpinner);// get the spinner
		
				String chosenBlock = stuSpinner.getSelectedItem().toString();// get the selected item
		
				Intent stuIntent = new Intent(this,SelectActivity.class);
				
			
				stuIntent.putExtra("STU_MESSAGE_BLOCK", chosenBlock);//data to store block letter
														   // the value that was chosen by the user
				
				stuIntent.putExtra("STU_MESSAGE_RES", result);
				Log.e("IntentBLOCK", chosenBlock);
				Log.e("IntentRES", result);
				startActivity(stuIntent);
		
		
				
				
	}
	
	public void GetStudents(View view){
		//!!!!!!!!!!!!USED FOR TESTING ONLY!!!!!!!!!!!!
		Intent xIntent = new Intent(this,SelectActivity.class);
	
		startActivity(xIntent);
	}


	@Override
	public void onItemSelected(AdapterView<?> stuParent, View stuView, int stuPosition,
			long stuId) {
		// TODO Auto-generated method stub
		stuParent.getItemAtPosition(stuPosition);
		// set a global url param to teh position
	}


	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
		
	}
	
	public  boolean testConnectivity(){
		ConnectivityManager man = (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
		NetworkInfo stuNet = man.getActiveNetworkInfo();
		// check connectivity manager and network info
		if (stuNet.isConnected() && stuNet != null){
			
			return true;// connection is ok
			
		}else{
			
			return false;// bad connection
		}
	}


class AsyncConnect extends AsyncTask<String, String, String>{

	@Override
	protected void onPreExecute(){

	}
	@Override
	// start of Android setup variables
	protected String doInBackground(String... arg0) {
		
		Spinner stuSpinner = (Spinner)findViewById(R.id.blockSpinner);// get the spinner
		
		String chosenBlock = stuSpinner.getSelectedItem().toString();// get the selected item
		
		Log.e("GotCorrectData?", chosenBlock);//DEBUG
		// TODO Auto-generated method stub
		//Connection Variables
				String stuUri = "?id=1&block="; //add the correct variable to stuUri for result
												// Separate by & sign
												// set the id to the right phase and set variable i to the id in php
				String URL = "http://10.0.2.2:81/phpSwitch.php";
				stuUri += chosenBlock + "&act=null";// adding the block to the uri// setting the act to null b/c it its not used yet
				URL += stuUri;// add the query to the url
				HttpClient stuClient = new DefaultHttpClient();
				HttpGet stuDataGet = new HttpGet(URL);// use 10.0.2.2 to access localhost adding :<port number> for the specific port used.
				InputStream stuin = null;
				HttpResponse stuRes = null;
				String result;
				String paramAppend = ""; // used to append the parameters for the get method
				
				
					//try catch section
				
				//if(testConnectivity()){

						try{
						stuRes = stuClient.execute(stuDataGet);// execute the get request
						}catch(Exception e){
							
							Log.e("Client", e.toString());
							e.printStackTrace();
						}

						try{
						stuin = stuRes.getEntity().getContent();// get the content of the response
						
						}catch(Exception e){
							
							Log.e("ENT", e.toString());
							e.printStackTrace();
						}

					
						result = InStreamReader(stuin);// parse the string

					
				//}
						
						
		return result;// change to returning a string
		
	}
	
	// do the queries here
	public String InStreamReader(InputStream in){

		// parse the data into a string
		BufferedReader strRead = new BufferedReader(new InputStreamReader(in));
		
		StringBuilder stuBuild = new StringBuilder();// Creating the variables
		
		String text = null;
		
		try {
			while((text = strRead.readLine()) !=null){
			
			stuBuild.append(text);// append data to the string until the data runs out.
										//changed to ; from \n to separate the data.
										// don't add anything if conversion is ok
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		String cat = stuBuild.toString();
		
		//cat = cat.replace("[", "{");  // code to alter data to help with parsing
		//cat = cat.replace("]", "}");  // use {}
		
		// if the append method can't do it.
		
		return cat;
	}

}

}