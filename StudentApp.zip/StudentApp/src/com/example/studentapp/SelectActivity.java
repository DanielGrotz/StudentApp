package com.example.studentapp;
// imports
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.net.*;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.app.*;
import android.content.Intent;
import org.json.*;
//main class
public class SelectActivity extends Activity{// surrounds async connect
	


	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);
        
    	Intent stuInt = getIntent();// get the incoming intent
    	
    	//String block = stuInt.getStringExtra("STU_MESSAGE_BLOCK");// data received in async connect
    	
    	String result = stuInt.getStringExtra("STU_MESSAGE_RES");
    	
    	String[] StudentArray = ActArrayCon(result);// convert the array to normal array
    	
    	List<String> stuList = new ArrayList<String>();
    	for(int i = 0; i < StudentArray.length - 1; i++){
    		stuList.add(StudentArray[i]);
    		
    	}
    	// create function to add the array elemetns to the list
    	
    	//Log.e("testARRAY", StudentArray.toString());
    														// create array from incoming result//new String[]{result}
        
        Spinner actSpinner = (Spinner) findViewById(R.id.actSpinner);// create act spinner
        
        
        ArrayAdapter<String> stuAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, stuList);// creating the spinner data from array
        
        stuAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);// set the proper layout
        
        actSpinner.setAdapter(stuAdapter);
        
        //actSpinner.setOnItemSelectedListener(this);
        
        String origin;
        String SpinData; // data to add to spinner
        Bundle check;
        
	}
	
	
	private String[] ActArrayCon (String result){// converter for activities array
		
		JSONObject stuObj = null;
		JSONArray stuArr = null;
		String stuStringJ = "X";// DEBUG
		try {
			stuObj = new JSONObject(result);
			stuArr = stuObj.getJSONArray("Activities");// get the correct array
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			Log.e("JsonError", e1.toString());
		}
		String[] stringArray = new String[stuArr.length()];
		
		for(int i = 0; i < stuArr.length() - 1; i++){// loop through json array
			try {
				stuStringJ = stuArr.getJSONObject(i).getString("ActName");// gets the camper id, first name and last name
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				Log.e("ForLoopError", e.toString());
			}
			
			stringArray[i] = stuStringJ;// adds the string to a regular string array to be used with spinner/checkbox
			//Log.e("Is It Null?", stuStringJ);//DEBUG
		}
		
		
		
		return stringArray;
	}

	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
	
	public void GetStudents(View view){
		//!!!!!!!!!!!!!!!!USED FOR TESTING ONLY!!!!!!
		// make this return to home page?
		Intent actIntent = new Intent(this,CheckinStudents.class);
		
		startActivity(actIntent);
		
	}


	public void SendData(View view) throws ClientProtocolException, IOException, InterruptedException, ExecutionException{
		
				String Sndresult = new AsyncConnectSelect().execute().get();
		
				//Spinner actSpinner = (Spinner) findViewById(R.id.actSpinner);
				
				//String chosenAct = actSpinner.getSelectedItem().toString();
				
				Intent stuIntent = new Intent(this,SelectActivity.class);
				
				//stuIntent.putExtra("STU_MESSAGE_ACT", chosenAct);
				// unnecessary to pass on activity data
				stuIntent.putExtra("STU_MESSAGE_RES2", Sndresult);
				Log.e("SNDIntentRES", Sndresult);
				startActivity(stuIntent);
		
		

	}
	


class AsyncConnectSelect extends AsyncTask<String, String, String>{

	Spinner actSpinner = (Spinner) findViewById(R.id.actSpinner);// get the spinner
	String stuAct = actSpinner.getSelectedItem().toString();// get the selected item
	
	Intent stuInt = getIntent();
	String block = stuInt.getStringExtra("STU_MESSAGE_BLOCK");
	
	@Override
	// start of Android setup variables
	protected String doInBackground(String... arg0) {
		// TODO Auto-generated method stub
		//Connection Variables
				String stuUri = "?id=2&block="; //add the correct variable to stuUri for result
												// Separate by & sign
												// id should be 2
												// set the id to the right phase and set variable i to the id in php
				String URL = "http://10.0.2.2:81/phpSwitch.php";
				stuUri += block + "&act=" + stuAct;// adding the block to the uri// also add the act to the uri
										  // get the act from the spinner
				URL += stuUri;// add the query to the url
				
				HttpClient stuClient = new DefaultHttpClient();
				HttpGet stuDataGet = new HttpGet(URL);
				InputStream stuin = null;//10.9.2.62 ip address for dunwoody laptop
				HttpResponse stuRes = null;
				String result;
				
				
				
					//try catch section
				
				//if(testConnectivity()){

						try{
						stuRes = stuClient.execute(stuDataGet);// execute the get request
						}catch(Exception e){
							
							Log.e("Client", e.toString());
							e.printStackTrace();
						}

						try{
						stuin = stuRes.getEntity().getContent();// get the content of the response
						
						}catch(Exception e){
							
							Log.e("ENT", e.toString());
							e.printStackTrace();
						}

					
						result = InStreamReader(stuin);// parse the string

				//}
						
						
		return result;// change to returning a string
					  // Supposed to be null?
	}
	
	// do the queries here
	public String InStreamReader(InputStream in){

		// parse the data into a string
		BufferedReader strRead = new BufferedReader(new InputStreamReader(in));
		
		StringBuilder stuBuild = new StringBuilder();// Creating the variables
		
		String text = null;
		
		try {
			while((text = strRead.readLine()) !=null){
			
			stuBuild.append(text);// append data to the string until the data runs out.
										//changed to ; from \n to separate the data.
										// don't add anything if conversion is ok
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String cat = stuBuild.toString();
		
		//cat = cat.replace("[", "");  // code to alter data to help with parsing
		//cat = cat.replace("]", "");// Do not use
		
		
		return cat;
	}

}

}
